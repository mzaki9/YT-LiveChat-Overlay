/**
 * Integration script to add performance monitoring to existing chat functions
 */

// Wait for the extension to load
(function() {
  'use strict';
  
  let integrationRetries = 0;
  const maxRetries = 50;
  
  function integratePerformanceMonitoring() {
    // Check if required functions exist
    if (typeof updateChatMessages === 'undefined' || 
        typeof createChatMessageElement === 'undefined') {
      
      integrationRetries++;
      if (integrationRetries < maxRetries) {
        setTimeout(integratePerformanceMonitoring, 200);
        return;
      } else {
        console.log('[Performance Integration] Functions not found, skipping integration');
        return;
      }
    }
    
    console.log('[Performance Integration] Integrating performance monitoring');
    
    // Store original functions
    const originalUpdateChatMessages = window.updateChatMessages;
    const originalCreateChatMessageElement = window.createChatMessageElement;
    
    // Wrap updateChatMessages with performance monitoring
    window.updateChatMessages = function(liveChatFrame, chatMessagesContainer) {
      if (window.ytChatPerformanceMonitor && window.ytChatPerformanceMonitor.isMonitoring) {
        return window.ytChatPerformanceMonitor.measureChatUpdate(() => {
          const result = originalUpdateChatMessages.call(this, liveChatFrame, chatMessagesContainer);
          
          // Track message processing
          if (result) {
            window.ytChatPerformanceMonitor.trackMessageProcessed(false, false);
          }
          
          return result;
        });
      } else {
        return originalUpdateChatMessages.call(this, liveChatFrame, chatMessagesContainer);
      }
    };
    
    // Wrap createChatMessageElement with performance monitoring
    window.createChatMessageElement = function(authorName, authorPhoto, badgeUrl, messageText, authorClass, messageHTML) {
      if (window.ytChatPerformanceMonitor && window.ytChatPerformanceMonitor.isMonitoring) {
        return window.ytChatPerformanceMonitor.measureDOMOperation(() => {
          return originalCreateChatMessageElement.call(this, authorName, authorPhoto, badgeUrl, messageText, authorClass, messageHTML);
        });
      } else {
        return originalCreateChatMessageElement.call(this, authorName, authorPhoto, badgeUrl, messageText, authorClass, messageHTML);
      }
    };
    
    // Add memory monitoring to element pool operations if available
    if (typeof elementPool !== 'undefined' && elementPool.recycle) {
      const originalRecycle = elementPool.recycle;
      
      elementPool.recycle = function(element) {
        if (window.ytChatPerformanceMonitor && window.ytChatPerformanceMonitor.isMonitoring) {
          return window.ytChatPerformanceMonitor.measureDOMOperation(() => {
            return originalRecycle.call(this, element);
          }, 'recycle');
        } else {
          return originalRecycle.call(this, element);
        }
      };
    }
    
    console.log('[Performance Integration] Successfully integrated performance monitoring');
    
    // Add console commands for easy access
    window.startPerformanceMonitoring = function() {
      if (window.ytChatPerformanceMonitor) {
        window.ytChatPerformanceMonitor.startMonitoring();
        console.log('Performance monitoring started. Use stopPerformanceMonitoring() to stop.');
      }
    };
    
    window.stopPerformanceMonitoring = function() {
      if (window.ytChatPerformanceMonitor) {
        window.ytChatPerformanceMonitor.stopMonitoring();
      }
    };
    
    window.runBenchmark = function() {
      if (window.ytChatBenchmark) {
        return window.ytChatBenchmark.runFullBenchmark();
      }
    };
    
    window.startLiveTest = function() {
      if (window.ytChatBenchmark) {
        window.ytChatBenchmark.startLivePerformanceTest();
        console.log('Live performance test started for 60 seconds');
      }
    };
    
    window.exportPerformanceData = function() {
      if (window.ytChatPerformanceMonitor) {
        const data = window.ytChatPerformanceMonitor.exportMetrics();
        console.log('Performance data:', data);
        
        // Create downloadable file
        const blob = new Blob([data], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `yt-chat-overlay-performance-${new Date().toISOString().slice(0, 19)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        console.log('Performance data exported to file');
      }
    };
    
    // Show available commands
    console.group('[Performance Monitoring Commands]');
    console.log('startPerformanceMonitoring() - Start monitoring performance');
    console.log('stopPerformanceMonitoring() - Stop monitoring and show report');
    console.log('runBenchmark() - Run comprehensive benchmark suite');
    console.log('startLiveTest() - Start 60-second live performance test');
    console.log('exportPerformanceData() - Export performance data to JSON file');
    console.groupEnd();
  }
  
  // Start integration when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', integratePerformanceMonitoring);
  } else {
    setTimeout(integratePerformanceMonitoring, 1000);
  }
})();
