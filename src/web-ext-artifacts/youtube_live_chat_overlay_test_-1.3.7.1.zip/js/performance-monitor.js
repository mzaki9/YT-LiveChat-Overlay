/**
 * Performance monitoring and benchmarking for YouTube Live Chat Overlay
 */

class PerformanceMonitor {
  constructor() {
    this.metrics = {
      chatUpdates: {
        count: 0,
        totalTime: 0,
        avgTime: 0,
        maxTime: 0,
        minTime: Infinity
      },
      domOperations: {
        count: 0,
        totalTime: 0,
        avgTime: 0,
        maxTime: 0,
        minTime: Infinity
      },
      memoryUsage: {
        initialHeap: 0,
        currentHeap: 0,
        peakHeap: 0,
        elementPoolSize: 0
      },
      frameRate: {
        fps: 0,
        samples: [],
        avgFps: 0
      },
      chatMessages: {
        processed: 0,
        skipped: 0,
        errors: 0,
        rate: 0 // messages per second
      }
    };
    
    this.isMonitoring = false;
    this.startTime = 0;
    this.lastFrameTime = 0;
    this.frameCount = 0;
    this.reportInterval = null;
    
    // Performance observers
    this.observers = [];
    this.setupPerformanceObservers();
  }

  startMonitoring() {
    if (this.isMonitoring) return;
    
    this.isMonitoring = true;
    this.startTime = performance.now();
    this.metrics.memoryUsage.initialHeap = this.getMemoryUsage();
    
    // Start FPS monitoring
    this.monitorFrameRate();
    
    // Start periodic reporting
    this.reportInterval = setInterval(() => {
      this.generateReport();
    }, 5000); // Report every 5 seconds
    
    console.log("[Performance Monitor] Started monitoring");
  }

  stopMonitoring() {
    if (!this.isMonitoring) return;
    
    this.isMonitoring = false;
    
    if (this.reportInterval) {
      clearInterval(this.reportInterval);
      this.reportInterval = null;
    }
    
    // Cleanup observers
    this.observers.forEach(observer => observer.disconnect());
    this.observers = [];
    
    // Final report
    this.generateReport(true);
    console.log("[Performance Monitor] Stopped monitoring");
  }

  // Track chat update performance
  measureChatUpdate(callback) {
    if (!this.isMonitoring) return callback();
    
    const startTime = performance.now();
    const result = callback();
    const endTime = performance.now();
    const duration = endTime - startTime;
    
    this.updateMetric('chatUpdates', duration);
    return result;
  }

  // Track DOM operation performance
  measureDOMOperation(callback, operationType = 'generic') {
    if (!this.isMonitoring) return callback();
    
    const startTime = performance.now();
    const result = callback();
    const endTime = performance.now();
    const duration = endTime - startTime;
    
    this.updateMetric('domOperations', duration);
    return result;
  }

  // Track message processing
  trackMessageProcessed(wasSkipped = false, hasError = false) {
    if (!this.isMonitoring) return;
    
    if (hasError) {
      this.metrics.chatMessages.errors++;
    } else if (wasSkipped) {
      this.metrics.chatMessages.skipped++;
    } else {
      this.metrics.chatMessages.processed++;
    }
    
    // Calculate message rate
    const totalTime = (performance.now() - this.startTime) / 1000;
    this.metrics.chatMessages.rate = this.metrics.chatMessages.processed / totalTime;
  }

  // Update memory tracking
  updateMemoryUsage() {
    if (!this.isMonitoring) return;
    
    const current = this.getMemoryUsage();
    this.metrics.memoryUsage.currentHeap = current;
    
    if (current > this.metrics.memoryUsage.peakHeap) {
      this.metrics.memoryUsage.peakHeap = current;
    }
    
    // Track element pool size if available
    if (typeof elementPool !== 'undefined') {
      this.metrics.memoryUsage.elementPoolSize = 
        (elementPool.messages?.length || 0) +
        (elementPool.profileImgs?.length || 0) +
        (elementPool.authors?.length || 0) +
        (elementPool.messageTexts?.length || 0) +
        (elementPool.badges?.length || 0) +
        (elementPool.contentContainers?.length || 0);
    }
  }

  // Get memory usage
  getMemoryUsage() {
    if (performance.memory) {
      return Math.round(performance.memory.usedJSHeapSize / 1024 / 1024 * 100) / 100; // MB
    }
    return 0;
  }

  // Monitor frame rate
  monitorFrameRate() {
    if (!this.isMonitoring) return;
    
    const now = performance.now();
    
    if (this.lastFrameTime > 0) {
      const fps = 1000 / (now - this.lastFrameTime);
      this.metrics.frameRate.samples.push(fps);
      
      // Keep only last 60 samples
      if (this.metrics.frameRate.samples.length > 60) {
        this.metrics.frameRate.samples.shift();
      }
      
      // Calculate average FPS
      this.metrics.frameRate.avgFps = 
        this.metrics.frameRate.samples.reduce((a, b) => a + b, 0) / 
        this.metrics.frameRate.samples.length;
      
      this.metrics.frameRate.fps = fps;
    }
    
    this.lastFrameTime = now;
    this.frameCount++;
    
    requestAnimationFrame(() => this.monitorFrameRate());
  }

  // Setup performance observers
  setupPerformanceObservers() {
    try {
      // Long task observer
      if ('PerformanceObserver' in window) {
        const longTaskObserver = new PerformanceObserver((list) => {
          const entries = list.getEntries();
          entries.forEach(entry => {
            if (entry.duration > 50) { // Tasks longer than 50ms
              console.warn(`[Performance Monitor] Long task detected: ${entry.duration}ms`);
            }
          });
        });
        
        longTaskObserver.observe({ entryTypes: ['longtask'] });
        this.observers.push(longTaskObserver);
      }
    } catch (e) {
      console.log("[Performance Monitor] Some performance observers not available");
    }
  }

  // Update metric helper
  updateMetric(metricType, duration) {
    const metric = this.metrics[metricType];
    metric.count++;
    metric.totalTime += duration;
    metric.avgTime = metric.totalTime / metric.count;
    
    if (duration > metric.maxTime) {
      metric.maxTime = duration;
    }
    
    if (duration < metric.minTime) {
      metric.minTime = duration;
    }
  }

  // Generate performance report
  generateReport(isFinal = false) {
    if (!this.isMonitoring && !isFinal) return;
    
    this.updateMemoryUsage();
    
    const totalTime = (performance.now() - this.startTime) / 1000;
    
    const report = {
      timestamp: new Date().toISOString(),
      duration: `${totalTime.toFixed(2)}s`,
      chatUpdates: {
        count: this.metrics.chatUpdates.count,
        avgTime: `${this.metrics.chatUpdates.avgTime.toFixed(2)}ms`,
        maxTime: `${this.metrics.chatUpdates.maxTime.toFixed(2)}ms`,
        minTime: this.metrics.chatUpdates.minTime === Infinity ? 0 : `${this.metrics.chatUpdates.minTime.toFixed(2)}ms`,
        updatesPerSecond: (this.metrics.chatUpdates.count / totalTime).toFixed(2)
      },
      domOperations: {
        count: this.metrics.domOperations.count,
        avgTime: `${this.metrics.domOperations.avgTime.toFixed(2)}ms`,
        maxTime: `${this.metrics.domOperations.maxTime.toFixed(2)}ms`,
        opsPerSecond: (this.metrics.domOperations.count / totalTime).toFixed(2)
      },
      memory: {
        initial: `${this.metrics.memoryUsage.initialHeap}MB`,
        current: `${this.metrics.memoryUsage.currentHeap}MB`,
        peak: `${this.metrics.memoryUsage.peakHeap}MB`,
        elementPoolSize: this.metrics.memoryUsage.elementPoolSize,
        growth: `${(this.metrics.memoryUsage.currentHeap - this.metrics.memoryUsage.initialHeap).toFixed(2)}MB`
      },
      frameRate: {
        current: `${this.metrics.frameRate.fps.toFixed(1)} FPS`,
        average: `${this.metrics.frameRate.avgFps.toFixed(1)} FPS`,
        samples: this.metrics.frameRate.samples.length
      },
      chatMessages: {
        processed: this.metrics.chatMessages.processed,
        skipped: this.metrics.chatMessages.skipped,
        errors: this.metrics.chatMessages.errors,
        rate: `${this.metrics.chatMessages.rate.toFixed(2)} msg/s`,
        efficiency: `${((this.metrics.chatMessages.processed / (this.metrics.chatMessages.processed + this.metrics.chatMessages.skipped)) * 100).toFixed(1)}%`
      }
    };
    
    console.group(`[Performance Report${isFinal ? ' - FINAL' : ''}]`);
    console.table(report);
    console.groupEnd();
    
    return report;
  }

  // Benchmark specific scenarios
  async benchmarkScenario(scenarioName, testFunction, iterations = 100) {
    console.log(`[Performance Monitor] Starting benchmark: ${scenarioName}`);
    
    const results = [];
    
    for (let i = 0; i < iterations; i++) {
      const startTime = performance.now();
      await testFunction();
      const endTime = performance.now();
      results.push(endTime - startTime);
    }
    
    const analysis = this.analyzeResults(results);
    
    console.group(`[Benchmark Results: ${scenarioName}]`);
    console.log(`Iterations: ${iterations}`);
    console.log(`Average: ${analysis.average.toFixed(2)}ms`);
    console.log(`Median: ${analysis.median.toFixed(2)}ms`);
    console.log(`Min: ${analysis.min.toFixed(2)}ms`);
    console.log(`Max: ${analysis.max.toFixed(2)}ms`);
    console.log(`95th percentile: ${analysis.p95.toFixed(2)}ms`);
    console.log(`Standard deviation: ${analysis.stdDev.toFixed(2)}ms`);
    console.groupEnd();
    
    return analysis;
  }

  analyzeResults(results) {
    const sorted = results.slice().sort((a, b) => a - b);
    const sum = results.reduce((a, b) => a + b, 0);
    const average = sum / results.length;
    
    const median = sorted.length % 2 === 0
      ? (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2
      : sorted[Math.floor(sorted.length / 2)];
    
    const p95Index = Math.floor(sorted.length * 0.95);
    const p95 = sorted[p95Index];
    
    const variance = results.reduce((acc, val) => acc + Math.pow(val - average, 2), 0) / results.length;
    const stdDev = Math.sqrt(variance);
    
    return {
      average,
      median,
      min: sorted[0],
      max: sorted[sorted.length - 1],
      p95,
      stdDev,
      results: sorted
    };
  }

  // Export metrics as JSON
  exportMetrics() {
    return JSON.stringify({
      ...this.metrics,
      exportTime: new Date().toISOString(),
      totalDuration: (performance.now() - this.startTime) / 1000
    }, null, 2);
  }
}

// Global performance monitor instance
window.ytChatPerformanceMonitor = new PerformanceMonitor();
