/**
 * Benchmarking utilities and test scenarios for YouTube Live Chat Overlay
 */

class ChatOverlayBenchmark {
  constructor() {
    this.monitor = window.ytChatPerformanceMonitor;
    this.mockChatData = this.generateMockChatData();
  }

  // Generate mock chat data for testing
  generateMockChatData(count = 1000) {
    const data = [];
    const usernames = ['TestUser', 'ChatMaster', 'StreamFan', 'LiveViewer', 'MessageSender'];
    const messages = [
      'Hello everyone!',
      'Great stream!',
      'This is awesome',
      'Love this content',
      'Keep it up!',
      'Amazing work',
      'So good!',
      'Fantastic!',
      'This is the best stream ever! 🔥🔥🔥',
      'Can you play my song request?'
    ];

    for (let i = 0; i < count; i++) {
      data.push({
        id: `mock-message-${i}`,
        authorName: usernames[Math.floor(Math.random() * usernames.length)],
        authorPhoto: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTIiIGN5PSIxMiIgcj0iMTAiIGZpbGw9IiNkZGQiLz4KPC9zdmc+',
        messageText: messages[Math.floor(Math.random() * messages.length)],
        badgeUrl: Math.random() > 0.8 ? 'badge.png' : null,
        authorClass: Math.random() > 0.9 ? 'author-member' : ''
      });
    }

    return data;
  }

  // Benchmark chat message creation
  async benchmarkMessageCreation() {
    const iterations = 100;
    
    return await this.monitor.benchmarkScenario(
      'Chat Message Creation',
      () => {
        const mockData = this.mockChatData[Math.floor(Math.random() * this.mockChatData.length)];
        
        // Simulate creating a chat message element
        if (typeof createChatMessageElement === 'function') {
          const element = createChatMessageElement(
            mockData.authorName,
            mockData.authorPhoto,
            mockData.badgeUrl,
            mockData.messageText,
            mockData.authorClass,
            mockData.messageText
          );
          
          // Clean up
          if (typeof elementPool !== 'undefined' && elementPool.recycle) {
            elementPool.recycle(element);
          }
        }
      },
      iterations
    );
  }

  // Benchmark DOM operations
  async benchmarkDOMOperations() {
    const iterations = 50;
    
    return await this.monitor.benchmarkScenario(
      'DOM Batch Operations',
      () => {
        const container = document.createElement('div');
        const fragment = document.createDocumentFragment();
        
        // Create multiple elements
        for (let i = 0; i < 10; i++) {
          const div = document.createElement('div');
          div.textContent = `Test message ${i}`;
          div.className = 'chat-message';
          fragment.appendChild(div);
        }
        
        container.appendChild(fragment);
        
        // Simulate removal
        while (container.firstChild) {
          container.removeChild(container.firstChild);
        }
      },
      iterations
    );
  }

  // Benchmark element pool operations
  async benchmarkElementPool() {
    if (typeof elementPool === 'undefined') {
      console.warn('Element pool not available for benchmarking');
      return null;
    }

    const iterations = 200;
    
    return await this.monitor.benchmarkScenario(
      'Element Pool Operations',
      () => {
        // Get elements from pool
        const message = elementPool.getMessage();
        const author = elementPool.getAuthor();
        const text = elementPool.getMessageText();
        const profile = elementPool.getProfileImg();
        
        // Simulate usage
        message.className = 'chat-message';
        author.textContent = 'TestUser';
        text.textContent = 'Test message';
        profile.src = 'test.jpg';
        
        // Return to pool
        elementPool.recycle(message);
      },
      iterations
    );
  }

  // Benchmark chat update processing
  async benchmarkChatUpdateProcessing() {
    const iterations = 50;
    
    return await this.monitor.benchmarkScenario(
      'Chat Update Processing',
      () => {
        // Simulate processing multiple messages
        for (let i = 0; i < 5; i++) {
          const mockData = this.mockChatData[Math.floor(Math.random() * this.mockChatData.length)];
          
          // Simulate message ID checking
          const messageId = mockData.id;
          const isProcessed = Math.random() > 0.8; // 20% already processed
          
          if (!isProcessed) {
            // Simulate creating and adding message
            if (typeof createChatMessageElement === 'function') {
              const element = createChatMessageElement(
                mockData.authorName,
                mockData.authorPhoto,
                mockData.badgeUrl,
                mockData.messageText,
                mockData.authorClass,
                mockData.messageText
              );
              
              // Clean up
              if (typeof elementPool !== 'undefined' && elementPool.recycle) {
                elementPool.recycle(element);
              }
            }
          }
        }
      },
      iterations
    );
  }

  // Memory stress test
  async memoryStressTest(duration = 30000) {
    console.log(`[Benchmark] Starting memory stress test for ${duration}ms`);
    
    const startMemory = this.monitor.getMemoryUsage();
    const startTime = performance.now();
    
    let messageCount = 0;
    const interval = setInterval(() => {
      // Create and destroy messages rapidly
      for (let i = 0; i < 10; i++) {
        const mockData = this.mockChatData[Math.floor(Math.random() * this.mockChatData.length)];
        
        if (typeof createChatMessageElement === 'function') {
          const element = createChatMessageElement(
            mockData.authorName,
            mockData.authorPhoto,
            mockData.badgeUrl,
            mockData.messageText,
            mockData.authorClass,
            mockData.messageText
          );
          
          messageCount++;
          
          // Clean up
          if (typeof elementPool !== 'undefined' && elementPool.recycle) {
            elementPool.recycle(element);
          }
        }
      }
    }, 100);

    return new Promise((resolve) => {
      setTimeout(() => {
        clearInterval(interval);
        
        const endMemory = this.monitor.getMemoryUsage();
        const endTime = performance.now();
        
        const result = {
          duration: endTime - startTime,
          messagesCreated: messageCount,
          startMemory: startMemory,
          endMemory: endMemory,
          memoryGrowth: endMemory - startMemory,
          messagesPerSecond: messageCount / ((endTime - startTime) / 1000)
        };
        
        console.group('[Memory Stress Test Results]');
        console.log(`Duration: ${result.duration.toFixed(2)}ms`);
        console.log(`Messages created: ${result.messagesCreated}`);
        console.log(`Start memory: ${result.startMemory}MB`);
        console.log(`End memory: ${result.endMemory}MB`);
        console.log(`Memory growth: ${result.memoryGrowth.toFixed(2)}MB`);
        console.log(`Messages/second: ${result.messagesPerSecond.toFixed(2)}`);
        console.groupEnd();
        
        resolve(result);
      }, duration);
    });
  }

  // Run comprehensive benchmark suite
  async runFullBenchmark() {
    console.log('[Benchmark] Starting comprehensive benchmark suite');
    
    this.monitor.startMonitoring();
    
    const results = {
      messageCreation: await this.benchmarkMessageCreation(),
      domOperations: await this.benchmarkDOMOperations(),
      elementPool: await this.benchmarkElementPool(),
      chatProcessing: await this.benchmarkChatUpdateProcessing(),
      memoryStress: await this.memoryStressTest(10000) // 10 second stress test
    };
    
    this.monitor.stopMonitoring();
    
    console.group('[Full Benchmark Results Summary]');
    console.log('Message Creation Avg:', results.messageCreation?.average.toFixed(2) + 'ms');
    console.log('DOM Operations Avg:', results.domOperations?.average.toFixed(2) + 'ms');
    console.log('Element Pool Avg:', results.elementPool?.average?.toFixed(2) + 'ms' || 'N/A');
    console.log('Chat Processing Avg:', results.chatProcessing?.average.toFixed(2) + 'ms');
    console.log('Memory Growth:', results.memoryStress?.memoryGrowth.toFixed(2) + 'MB');
    console.groupEnd();
    
    return results;
  }

  // Benchmark real-time performance during actual chat
  startLivePerformanceTest() {
    console.log('[Benchmark] Starting live performance monitoring');
    
    this.monitor.startMonitoring();
    
    // Hook into the actual updateChatMessages function if available
    if (typeof updateChatMessages === 'function') {
      const originalUpdateChatMessages = updateChatMessages;
      
      window.updateChatMessages = function(liveChatFrame, chatMessagesContainer) {
        return window.ytChatPerformanceMonitor.measureChatUpdate(() => {
          return originalUpdateChatMessages.call(this, liveChatFrame, chatMessagesContainer);
        });
      };
      
      console.log('[Benchmark] Hooked into updateChatMessages for real-time monitoring');
    }
    
    // Monitor for 60 seconds then generate report
    setTimeout(() => {
      this.stopLivePerformanceTest();
    }, 60000);
  }

  stopLivePerformanceTest() {
    console.log('[Benchmark] Stopping live performance monitoring');
    this.monitor.stopMonitoring();
  }
}

// Global benchmark instance
window.ytChatBenchmark = new ChatOverlayBenchmark();
