if (window.top !== window) {
  throw new Error('YT Chat Overlay: not running in top frame');
}

let chatAPIActive = false;
let chatAPIWorkerInjected = false;

let videoPlayer;
let liveChatFrame;
let overlayChatContainer;
let chatMessagesContainer;
let toggleButton;
let keyboardShortcutListener;
let fullscreenChangeListener;
let injectionInterval;
let urlObserver;
let messageListener;
let apiMessageListener;

function detectLivestream() {
  if (window.ytInitialPlayerResponse?.videoDetails?.isLiveContent) return true;
  if (document.querySelector('[badge-label="LIVE"], .ytp-liv-badge, ytd-badge-support-level[type="live"]')) return true;
  if (document.querySelector('iframe[src*="live_chat"], ytd-live-chat-frame, #chat')) return true;
  if (location.href.includes('live_chat')) return true;
  const t = document.title.toLowerCase();
  if (t.includes('(live)') || t.includes('streaming') || t.includes('livestream')) return true;
  return false;
}

function handleFullscreenChange() {
  if (!videoPlayer || !overlayChatContainer || !toggleButton) {
    log("Elements not ready during fullscreen change");
    return;
  }
  const isLivestream = detectLivestream();
  if (document.fullscreenElement || isLivestream) {
    toggleButton.style.display = "block";
    toggleButton.classList.add("show");
    const savedState = localStorage.getItem("youtubeOverlayVisible");
    if (savedState === "true") {
      isOverlayVisible = true;
      overlayChatContainer.style.display = "block";
      overlayChatContainer.classList.add("show");
      if (liveChatFrame) startChatObservation(liveChatFrame, chatMessagesContainer);
    }
  } else {
    toggleButton.style.display = "none";
    toggleButton.classList.remove("show");
    overlayChatContainer.style.display = "none";
    overlayChatContainer.classList.remove("show");
    stopChatObservation();
  }
}

function cleanupAllListeners() {
  stopChatObservation();
  clearInterval(injectionInterval);

  if (chatAPIActive) stopChatAPIWorker();
  chatAPIActive = false;

  if (keyboardShortcutListener) {
    document.removeEventListener('keydown', keyboardShortcutListener);
    keyboardShortcutListener = null;
  }
  if (fullscreenChangeListener) {
    document.removeEventListener('fullscreenchange', fullscreenChangeListener);
    fullscreenChangeListener = null;
  }
  if (messageListener) {
    chrome.runtime.onMessage.removeListener(messageListener);
    messageListener = null;
  }
  if (apiMessageListener) {
    window.removeEventListener('message', apiMessageListener);
    apiMessageListener = null;
  }
  if (urlObserver) {
    urlObserver.disconnect();
    urlObserver = null;
  }
  cleanupOverlay();
}

function logD(tag, msg) {
  if (localStorage.getItem('chatOverlayDebug') === 'true') console.log('[YT ' + tag + '] ' + msg);
}

function createFragmentFromRuns(runs) {
  const frag = document.createDocumentFragment();
  if (!runs) return frag;
  for (let i = 0; i < runs.length; i++) {
    const run = runs[i];
    if (run.emoji && run.emoji.image && run.emoji.image.thumbnails) {
      const thumb = run.emoji.image.thumbnails[0];
      if (thumb && thumb.url) {
        const img = document.createElement('img');
        img.src = thumb.url;
        img.alt = run.emoji.shortcuts ? run.emoji.shortcuts[0] : '';
        img.className = 'chat-emoticon';
        img.style.cssText = 'height:1.5em;width:auto;vertical-align:middle;object-fit:contain;display:inline-block;margin:0 0.1em';
        frag.appendChild(img);
      }
    } else if (run.text) {
      frag.appendChild(document.createTextNode(run.text));
    }
  }
  frag.isDocumentFragment = true;
  return frag;
}

function getTextFromRuns(runs) {
  if (!runs) return '';
  let text = '';
  for (let i = 0; i < runs.length; i++) {
    if (runs[i].text) text += runs[i].text;
  }
  return text;
}

function getBadgeFromRenderer(renderer) {
  try {
    const badges = renderer.authorBadges;
    if (!badges || !badges[0]) return null;
    const badge = badges[0].liveChatAuthorBadgeRenderer;
    if (!badge) return null;
    if (badge.customThumbnail && badge.customThumbnail.thumbnails && badge.customThumbnail.thumbnails[0]) {
      return badge.customThumbnail.thumbnails[0].url;
    }
    if (badge.icon && badge.icon.thumbnails && badge.icon.thumbnails[0]) {
      return badge.icon.thumbnails[0].url;
    }
  } catch (e) {}
  return null;
}

function renderAPIMessage(renderer, container) {
  const id = renderer.id;
  logD('API', 'renderAPIMessage id=' + id);
  if (!id || isMessageProcessed(id)) { logD('API', 'Skipped (duplicate or no id)'); return; }
  addProcessedMessageId(id);

  const authorName = (renderer.authorName && renderer.authorName.simpleText) || (renderer.authorName && renderer.authorName.runs && renderer.authorName.runs[0] && renderer.authorName.runs[0].text);
  if (!authorName) { logD('API', 'Skipped (no author)'); return; }

  const authorPhoto = renderer.authorPhoto && renderer.authorPhoto.thumbnails && renderer.authorPhoto.thumbnails[0] ? renderer.authorPhoto.thumbnails[0].url : '';
  const badgeUrl = getBadgeFromRenderer(renderer);
  const runs = renderer.message && renderer.message.runs;
  const messageFragment = createFragmentFromRuns(runs);
  const messageText = getTextFromRuns(runs);

  logD('API', 'Rendering: ' + authorName + ': ' + messageText);
  const el = createChatMessageElement(authorName, authorPhoto, badgeUrl, messageText, '', messageFragment);
  container.appendChild(el);

  const children = container.childElementCount;
  if (children > 100) {
    const remove = children - 100;
    for (let i = 0; i < remove; i++) {
      const first = container.firstChild;
      if (first) { container.removeChild(first); elementPool.recycle(first); }
    }
  }
}

function processAPIBatch(actions) {
  logD('API', 'processAPIBatch: ' + (actions ? actions.length : 0) + ' actions, container=' + !!chatMessagesContainer + ' visible=' + !!isOverlayVisible);
  if (!chatMessagesContainer || !isOverlayVisible) return;
  var rendered = 0;
  for (let i = 0; i < actions.length; i++) {
    const action = actions[i];
    if (!action) continue;
    var actionKeys = Object.keys(action);
    if (actionKeys.indexOf('addChatItemAction') === -1) { logD('API', 'Action type: ' + actionKeys.join(',')); continue; }
    const item = action.addChatItemAction.item;
    if (!item) continue;
    var itemKeys = Object.keys(item);
    const renderer = item.liveChatTextMessageRenderer || item.liveChatPaidMessageRenderer || item.liveChatMembershipItemRenderer;
    if (renderer) { renderAPIMessage(renderer, chatMessagesContainer); rendered++; }
    else logD('API', 'Unhandled renderer type: ' + itemKeys.join(','));
  }
  logD('API', 'Rendered ' + rendered + ' messages');
  if (chatMessagesContainer.scrollTop + chatMessagesContainer.clientHeight >= chatMessagesContainer.scrollHeight - 50) {
    requestAnimationFrame(() => { chatMessagesContainer.scrollTop = chatMessagesContainer.scrollHeight; });
  }
}

function injectChatAPIWorker() {
  if (chatAPIWorkerInjected) { logD('API', 'injectChatAPIWorker: already injected'); return; }
  const existing = document.getElementById('yt-chat-api-worker');
  if (existing) { chatAPIWorkerInjected = true; logD('API', 'injectChatAPIWorker: found existing'); return; }
  const url = chrome.runtime.getURL('js/chat-api-worker.js');
  logD('API', 'Injecting worker from: ' + url);
  const script = document.createElement('script');
  script.id = 'yt-chat-api-worker';
  script.src = url;
  document.head.appendChild(script);
  chatAPIWorkerInjected = true;
  logD('API', 'Worker script tag appended');
}

function startChatAPIWorker() {
  logD('API', 'startChatAPIWorker');
  injectChatAPIWorker();
  chatAPIActive = true;
}

function stopChatAPIWorker() {
  logD('API', 'stopChatAPIWorker');
  window.postMessage({ source: 'yt-overlay-ext', type: 'stop' }, '*');
  chatAPIActive = false;
}

function setupAPIMessageListener() {
  logD('API', 'setupAPIMessageListener');
  if (apiMessageListener) { logD('API', 'Listener already exists'); return; }
  apiMessageListener = function (e) {
    if (!e.data || e.data.source !== 'yt-overlay-worker') return;
    logD('API', 'Worker msg: type=' + e.data.type + ' data=' + (e.data.data ? (Array.isArray(e.data.data) ? e.data.data.length + ' items' : typeof e.data.data) : 'empty'));
    if (e.data.type === 'batch') processAPIBatch(e.data.data);
    if (e.data.type === 'ready') {
      logD('API', 'Worker ready, sending start');
      window.postMessage({ source: 'yt-overlay-ext', type: 'start' }, '*');
    }
  };
  window.addEventListener('message', apiMessageListener);
  logD('API', 'Message listener registered');
}

function injectLiveChatOverlay() {
  cleanupAllListeners();

  videoPlayer = document.querySelector(".html5-video-player") ||
                document.querySelector(".ytp-embed") ||
                document.querySelector("ytd-player") ||
                document.querySelector("#movie_player") ||
                document.querySelector(".ytd-player");

  if (!chatAPIActive) {
    liveChatFrame = findChatFrame();
  } else {
    liveChatFrame = null;
  }

  log('Video player found: ' + (videoPlayer ? 'Yes' : 'No'));
  log('Live chat frame found: ' + (liveChatFrame ? 'Yes' : 'No'));

  if (!videoPlayer || (!chatAPIActive && !liveChatFrame)) {
    log('Required elements not found' + (chatAPIActive ? ' (API mode)' : ''));
    return false;
  }

  try {
    log('Creating chat overlay...');
    const overlay = createChatOverlay(videoPlayer);
    overlayChatContainer = overlay.container;
    chatMessagesContainer = overlay.messagesContainer;
    log('Chat overlay created successfully');

    log('Creating toggle button...');
    toggleButton = createToggleButton(videoPlayer, () => {
      toggleOverlayChat(liveChatFrame, overlayChatContainer, chatMessagesContainer, toggleButton);
    });
    log('Toggle button created successfully');

    keyboardShortcutListener = (e) => {
      if (e.altKey && e.key.toLowerCase() === 'c' && document.fullscreenElement) {
        toggleOverlayChat(liveChatFrame, overlayChatContainer, chatMessagesContainer, toggleButton);
      }
    };
    document.addEventListener('keydown', keyboardShortcutListener);

    messageListener = (message, sender, sendResponse) => {
      switch (message.type) {
        case 'TOGGLE_OVERLAY':
          if ((liveChatFrame || chatAPIActive) && overlayChatContainer && chatMessagesContainer && toggleButton) {
            toggleOverlayChat(liveChatFrame, overlayChatContainer, chatMessagesContainer, toggleButton);
            sendResponse({ success: true });
          }
          break;
        default:
          sendResponse({ error: 'unknown_type' });
      }
      return true;
    };
    chrome.runtime.onMessage.addListener(messageListener);

    fullscreenChangeListener = handleFullscreenChange;
    document.addEventListener('fullscreenchange', fullscreenChangeListener, { passive: true });

    log('Initializing overlay state...');
    initializeOverlayState(overlayChatContainer, liveChatFrame, chatMessagesContainer);
    log('Overlay state initialized successfully');

    log('Triggering initial fullscreen state check...');
    handleFullscreenChange();

    if (chatAPIActive) setupAPIMessageListener();

    log('Chat overlay injection completed successfully' + (chatAPIActive ? ' (API mode)' : ''));
    return true;
  } catch (error) {
    log('Error during injection: ' + error.message);
    console.error('Full injection error:', error);
    return false;
  }
}

function setupUrlObserver() {
  const urlObserverCallback = debounce((mutations) => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;

      if (chatAPIActive) { stopChatAPIWorker(); chatAPIActive = false; }
      chatAPIWorkerInjected = false;

      if (detectLivestream()) {
        attemptChatDetection();
        setTimeout(() => attemptChatDetection(), 1000);
        setTimeout(() => attemptChatDetection(), 2500);
        setTimeout(() => attemptChatDetection(), 5000);
      }
    } else {
      const hasRelevantChanges = mutations && mutations.some(mutation => {
        if (!mutation.addedNodes?.length) return false;
        return Array.from(mutation.addedNodes).some(node => {
          if (node.nodeType !== Node.ELEMENT_NODE) return false;
          return node.id === 'chat' ||
                 node.matches?.('iframe[src*="live_chat"], ytd-live-chat-frame') ||
                 node.querySelector?.('iframe[src*="live_chat"], ytd-live-chat-frame');
        });
      });
      if (hasRelevantChanges) attemptChatDetection();
    }
  }, 200);

  urlObserver = new MutationObserver(urlObserverCallback);
  let lastUrl = location.href;
  urlObserver.observe(document.body, {
    childList: true,
    subtree: true,
    attributeFilter: ['id', 'src']
  });
}

function attemptChatDetection() {
  liveChatFrame = findChatFrame();

  if (!liveChatFrame && detectLivestream()) {
    const videoId = getVideoId();
    if (videoId) {
      log('No native chat, starting API polling for video ' + videoId);
      startChatAPIWorker();
      const success = injectLiveChatOverlay();
      if (success) {
        log('Overlay created in API mode');
        if (injectionInterval) { clearInterval(injectionInterval); injectionInterval = null; }
        return true;
      }
      chatAPIActive = false;
      return false;
    }
  }

  if (liveChatFrame) {
    log('Chat frame found, attempting to inject overlay');
    const success = injectLiveChatOverlay();
    if (success) {
      log('Successfully injected overlay after chat detection');
      if (injectionInterval) { clearInterval(injectionInterval); injectionInterval = null; }
      return true;
    } else {
      log('Injection failed during chat detection attempt');
      return false;
    }
  } else {
    log('No chat frame found during detection attempt');
    return false;
  }
}

if (document.readyState === 'complete') {
  const success = injectLiveChatOverlay();
  if (!success) {
    log('Initial injection failed, setting up retry mechanism');
    injectionInterval = setInterval(() => {
      const success = attemptChatDetection();
      if (success) { log('Successfully injected after retry'); }
    }, 1000);
    setTimeout(() => {
      if (injectionInterval) { clearInterval(injectionInterval); injectionInterval = null; log('Chat detection timed out - no livestream chat found'); }
    }, 30000);
  }
} else {
  window.addEventListener('load', () => {
    const success = injectLiveChatOverlay();
    if (!success) {
      log('Initial injection after load failed, setting up retry');
      setTimeout(() => attemptChatDetection(), 1000);
      setTimeout(() => attemptChatDetection(), 2500);
      setTimeout(() => attemptChatDetection(), 5000);
      injectionInterval = setInterval(() => {
        const success = attemptChatDetection();
        if (success) { log('Successfully injected after load and retry'); }
      }, 1000);
      setTimeout(() => {
        if (injectionInterval) { clearInterval(injectionInterval); log('Chat detection timed out after page load - no livestream chat found'); }
      }, 30000);
    }
  });
}

setupUrlObserver();
window.addEventListener('unload', cleanupAllListeners);
