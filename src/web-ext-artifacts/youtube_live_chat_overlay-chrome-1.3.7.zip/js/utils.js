/**
 * Utility functions for YouTube Live Chat Overlay
 */

// Debounce function to limit the rate of function execution
function debounce(func, wait) {
    let timeout;
    let lastCallTime = 0;
    
    return function executedFunction(...args) {
      const now = Date.now();
      const timeSinceLastCall = now - lastCallTime;
      
      // If enough time has passed, execute immediately
      if (timeSinceLastCall >= wait) {
        lastCallTime = now;
        return func.apply(this, args);
      }
      
      // Otherwise, schedule for later
      const later = () => {
        lastCallTime = Date.now();
        timeout = null;
        func.apply(this, args);
      };
      
      clearTimeout(timeout);
      timeout = setTimeout(later, wait - timeSinceLastCall);
    };
  }
  
 
  const isDebug = () => localStorage.getItem('chatOverlayDebug') === 'true';

  function log(message) {
    if (isDebug()) console.log(`[YT Chat Overlay] ${message}`);
  }

  function findChatFrame() {
  // Strategy 1: Inline chat (modern YouTube, no iframe)
  // YouTube renders chat directly in the page
  const liveChatElement = document.querySelector('ytd-live-chat-frame');
  if (liveChatElement) {
    if (liveChatElement.querySelector('yt-live-chat-text-message-renderer, #items, ytd-live-chat-item-list-renderer')) {
      return liveChatElement;
    }
    if (liveChatElement.shadowRoot) {
      const shadowContent = liveChatElement.shadowRoot.querySelector('#content, #items, ytd-live-chat-item-list-renderer');
      if (shadowContent) {
        return liveChatElement;
      }
    }
  }

  // Strategy 2: #chat container (inline div without iframe)
  const chatDiv = document.querySelector('#chat');
  if (chatDiv && chatDiv.querySelector('yt-live-chat-text-message-renderer, #items, ytd-live-chat-item-list-renderer')) {
    return chatDiv;
  }

  // Strategy 3: Iframe selectors (traditional approach)
  const iframeSelectors = [
    '#chat-frame',
    'iframe#chatframe',
    'iframe[src*="live_chat"]',
    'iframe[src*="www.youtube.com/live_chat"]',
    'iframe#chat',
    'ytd-live-chat-frame iframe',
    'ytd-watch-flexy ytd-live-chat-frame iframe',
    'ytd-watch-flexy #chat iframe',
    'ytd-live-chat-frame > iframe#chat',
    'iframe[src*="chat"]',
    'iframe[src*="comments"]',
  ];

  for (const selector of iframeSelectors) {
    const frame = document.querySelector(selector);
    if (frame && frame.contentDocument) {
      return frame;
    }
  }

  return null;
}

  function getColorFromName(name) {
    let hash = 0;
    const len = Math.min(name.length, 8);
    for (let i = 0; i < len; i++) {
      hash = (hash * 31 + name.charCodeAt(i)) & 0xFFFFFFFF;
    }
    
    const avoidRanges = [
      [100, 140], // green area (for members)
      [200, 240]  // blue area (for moderators)
    ];
    
    const h = (hash >>> 0) % 360;
    const s = 70 + ((hash >>> 0) % 20); 
    const l = 60 + ((hash >>> 0) % 15);
    
    let finalHue = h;
    for (const [min, max] of avoidRanges) {
      if (h >= min && h <= max) {
        finalHue = (h + 120) % 360;
        break;
      }
    }
    
    return `hsl(${finalHue}, ${s}%, ${l}%)`;
  }

  function getVideoId() {
    const p = new URLSearchParams(window.location.search);
    if (p.has('v')) return p.get('v');
    try {
      if (window.ytInitialPlayerResponse?.videoDetails?.videoId) {
        return window.ytInitialPlayerResponse.videoDetails.videoId;
      }
    } catch {}
    const og = document.querySelector('meta[property="og:url"]');
    if (og) {
      const m = og.content.match(/[?&]v=([^&]+)/);
      if (m) return m[1];
    }
    return null;
  }

