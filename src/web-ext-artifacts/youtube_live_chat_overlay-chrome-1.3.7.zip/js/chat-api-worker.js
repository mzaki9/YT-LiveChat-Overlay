(function () {
  var DW = '[YT Worker]';
  console.log(DW, 'Loaded');
  if (window.__ytChatAPIWorker) { console.log(DW, 'Already exists'); return; }
  const API_BASE = "https://www.youtube.com/youtubei/v1/live_chat";
  let state = { polling: false, continuation: null, timer: null };

  function getCookie(name) {
    const m = document.cookie.match(new RegExp("(?:^|;\\s*)" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^;]*)"));
    console.log(DW, 'Cookie ' + name + ':', m ? m[1].substring(0, 5) + '...' : 'NOT FOUND');
    return m ? m[1] : null;
  }

  function sha1(str) {
    function RotL(b, w) { return (w << b) | (w >>> (32 - b)); }
    function toHex(d) {
      let s = "";
      for (let i = 0; i < 4; i++) s += "0123456789abcdef".charAt((d >>> (i * 8 + 4)) & 15) + "0123456789abcdef".charAt((d >>> (i * 8)) & 15);
      return s;
    }
    let H = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0], W = new Array(80), A, B, C, D, E, T;
    str = unescape(encodeURIComponent(str));
    let w = [];
    for (let i = 0; i < str.length; i++) w[i >> 2] |= str.charCodeAt(i) << (24 - (i % 4) * 8);
    let len = str.length * 8;
    w.push(0x80);
    let pad = 8 - (str.length % 4);
    if (pad < 8) pad += 4;
    while (w.length % 16 !== 14) w.push(0);
    w.push(0);
    w.push(len);
    for (let b = 0; b < w.length; b += 16) {
      for (let t = 0; t < 16; t++) W[t] = w[b + t] || 0;
      for (let t = 16; t < 80; t++) W[t] = RotL(1, W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16]);
      A = H[0]; B = H[1]; C = H[2]; D = H[3]; E = H[4];
      for (let t = 0; t < 80; t++) {
        T = RotL(5, A) + (t < 20 ? (B & C) | (~B & D) : t < 40 ? B ^ C ^ D : t < 60 ? (B & C) | (B & D) | (C & D) : B ^ C ^ D) + E + W[t] + [0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xCA62C1D6][Math.floor(t / 20)];
        E = D; D = C; C = RotL(30, B); B = A; A = T >>> 0;
      }
      H[0] = (H[0] + A) >>> 0; H[1] = (H[1] + B) >>> 0; H[2] = (H[2] + C) >>> 0; H[3] = (H[3] + D) >>> 0; H[4] = (H[4] + E) >>> 0;
    }
    return toHex(H[0]) + toHex(H[1]) + toHex(H[2]) + toHex(H[3]) + toHex(H[4]);
  }

  function post(type, data) {
    window.postMessage({ source: "yt-overlay-worker", type, data }, "*");
  }

  function getConfig() {
    const cfg = window.ytcfg && window.ytcfg.data_;
    var result = cfg ? { key: cfg.INNERTUBE_API_KEY, context: cfg.INNERTUBE_CONTEXT } : null;
    console.log(DW, 'Config:', result ? 'found (key=' + result.key + ')' : 'NOT FOUND');
    return result;
  }

  function findContinuation(data) {
    try {
      const conts = data.contents.twoColumnWatchNextResults.conversationBar.liveChatRenderer.continuations;
      console.log(DW, 'findContinuation:', conts ? 'found ' + conts.length + ' continuations' : 'no continuations');
      if (conts && conts[0]) {
        const c = conts[0];
        var token = c.reloadContinuationData ? c.reloadContinuationData.continuation : c.timedContinuationData ? c.timedContinuationData.continuation : c.invalidationContinuationData ? c.invalidationContinuationData.continuation : null;
        console.log(DW, 'Continuation token:', token ? token.substring(0, 30) + '...' : 'null');
        return token;
      }
    } catch (e) { console.log(DW, 'findContinuation error:', e.message); }
    return null;
  }

  function getInitialActions(data) {
    try {
      var actions = data.contents.twoColumnWatchNextResults.conversationBar.liveChatRenderer.actions;
      console.log(DW, 'Initial actions:', actions ? actions.length + ' items' : 'none');
      return actions || null;
    } catch (e) { console.log(DW, 'getInitialActions error:', e.message); return null; }
  }

  function parseContinuationResponse(json) {
    try {
      const cont = json.continuationContents && json.continuationContents.liveChatContinuation;
      console.log(DW, 'parseContinuationResponse:', cont ? 'has continuation' : 'NO continuation content');
      if (!cont) {
        console.log(DW, 'Response keys:', Object.keys(json));
        if (json.error) console.log(DW, 'API Error:', json.error.message);
        return null;
      }
      const next = cont.continuations && cont.continuations[0];
      var nextToken = next ? (next.timedContinuationData ? next.timedContinuationData.continuation : next.invalidationContinuationData ? next.invalidationContinuationData.continuation : null) : null;
      console.log(DW, 'Actions in response:', cont.actions ? cont.actions.length : 0, 'Next token:', nextToken ? 'yes' : 'no');
      return {
        actions: cont.actions || null,
        nextContinuation: nextToken
      };
    } catch (e) { console.log(DW, 'parseContinuationResponse error:', e.message); return null; }
  }

  async function fetchContinuation() {
    const cfg = getConfig();
    if (!cfg || !cfg.key || !cfg.context || !state.continuation) {
      console.log(DW, 'fetchContinuation skipped:', { key: !!cfg, context: !!(cfg && cfg.context), cont: !!state.continuation });
      return;
    }
    const sapisid = getCookie("__Secure-3PAPISID");
    let headers = { "Content-Type": "application/json" };
    if (sapisid) {
      const ts = Math.floor(Date.now() / 1000);
      var hash = sha1(ts + " " + sapisid + " https://www.youtube.com");
      headers["Authorization"] = "SAPISIDHASH " + ts + "_" + hash;
      console.log(DW, 'Auth header set, hash:', hash.substring(0, 10) + '...');
    } else {
      console.log(DW, 'No SAPISID cookie - trying without auth');
    }
    try {
      var url = API_BASE + "/get_live_chat?key=" + cfg.key + "&prettyPrint=false";
      console.log(DW, 'Fetching:', url);
      const res = await fetch(url, { method: "POST", headers: headers, body: JSON.stringify({ context: cfg.context, continuation: state.continuation }) });
      console.log(DW, 'Response status:', res.status);
      const json = await res.json();
      console.log(DW, 'Response received');
      const parsed = parseContinuationResponse(json);
      if (parsed) {
        if (parsed.nextContinuation) { state.continuation = parsed.nextContinuation; console.log(DW, 'Updated continuation token'); }
        if (parsed.actions) { console.log(DW, 'Posting', parsed.actions.length, 'actions'); post("batch", parsed.actions); }
        else console.log(DW, 'No actions in response');
      } else {
        console.log(DW, 'Parse returned null');
      }
    } catch (e) { console.log(DW, 'Fetch error:', e.message); post("error", e.message); }
  }

  function poll() {
    if (!state.polling) return;
    fetchContinuation().then(function () { if (state.polling) state.timer = setTimeout(poll, 1500); });
  }

  window.__ytChatAPIWorker = {
    start: function () {
      console.log(DW, 'start() called');
      if (state.polling) { console.log(DW, 'Already polling'); return; }
      state.polling = true;
      var id = window.ytInitialData;
      console.log(DW, 'ytInitialData:', id ? 'exists' : 'null');
      if (id) {
        var c = findContinuation(id);
        if (c) { state.continuation = c; console.log(DW, 'Set continuation from initial data'); }
        var ia = getInitialActions(id);
        if (ia) { console.log(DW, 'Posting', ia.length, 'initial actions'); post("batch", ia); }
      }
      if (state.continuation) {
        console.log(DW, 'Starting poll cycle');
        fetchContinuation().then(function () { if (state.polling) state.timer = setTimeout(poll, 1500); });
      } else {
        console.log(DW, 'No continuation token - cannot poll');
        post("error", "No continuation token found");
      }
    },
    stop: function () { console.log(DW, 'stop() called'); state.polling = false; if (state.timer) { clearTimeout(state.timer); state.timer = null; } }
  };
  window.addEventListener("message", function (e) {
    console.log(DW, 'Received message:', e.data && e.data.type);
    if ((e.data || {}).source === "yt-overlay-ext" && e.data.type === "start") { console.log(DW, 'Starting via postMessage'); window.__ytChatAPIWorker.start(); }
    if ((e.data || {}).source === "yt-overlay-ext" && e.data.type === "stop") { console.log(DW, 'Stopping via postMessage'); window.__ytChatAPIWorker.stop(); }
  });
  console.log(DW, 'Posting ready');
  post("ready", {});
})();
