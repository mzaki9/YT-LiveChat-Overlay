/**
 * Utility functions for YouTube Live Chat Overlay
 */

// Debounce function to limit the rate of function execution
function debounce(func, wait) {
    let timeout;
    let lastCallTime = 0;
    
    return function executedFunction(...args) {
      const now = Date.now();
      const timeSinceLastCall = now - lastCallTime;
      
      // If enough time has passed, execute immediately
      if (timeSinceLastCall >= wait) {
        lastCallTime = now;
        return func.apply(this, args);
      }
      
      // Otherwise, schedule for later
      const later = () => {
        lastCallTime = Date.now();
        timeout = null;
        func.apply(this, args);
      };
      
      clearTimeout(timeout);
      timeout = setTimeout(later, wait - timeSinceLastCall);
    };
  }
  
 
  function log(message) {
    console.log(`[YT Chat Overlay] ${message}`);
  }

  function findChatFrame() {
  // Search for chat frame with various selectors
  const chatFrame = document.querySelector("#chat-frame") ||
    document.querySelector("iframe#chatframe") || 
    document.querySelector("iframe[src*='live_chat']") ||
    document.querySelector("iframe[src*='www.youtube.com/live_chat']") ||
    // Additional selectors for newer YouTube structure
    document.querySelector("iframe#chat") ||
    document.querySelector("ytd-live-chat-frame iframe") ||
    document.querySelector("ytd-watch-flexy ytd-live-chat-frame iframe") ||
    document.querySelector("ytd-watch-flexy #chat iframe") ||
    // More specific selectors based on potential new UIs
    document.querySelector("iframe[id='chatframe'][src*='live_chat']") ||
    document.querySelector("ytd-live-chat-frame > iframe#chat") ||
    // Broader fallback selectors
    document.querySelector("iframe[src*='chat']") ||
    document.querySelector("iframe[src*='comments']");
  
  return chatFrame;
}

  function getColorFromName(name) {
    let hash = 0;
    const len = Math.min(name.length, 8);
    for (let i = 0; i < len; i++) {
      hash = (hash * 31 + name.charCodeAt(i)) & 0xFFFFFFFF;
    }
    
    const avoidRanges = [
      [100, 140], // green area (for members)
      [200, 240]  // blue area (for moderators)
    ];
    
    const h = (hash >>> 0) % 360;
    const s = 70 + ((hash >>> 0) % 20); 
    const l = 60 + ((hash >>> 0) % 15);
    
    let finalHue = h;
    for (const [min, max] of avoidRanges) {
      if (h >= min && h <= max) {
        finalHue = (h + 120) % 360;
        break;
      }
    }
    
    // Use template literal only once at the end
    return `hsl(${finalHue}, ${s}%, ${l}%)`;
  }