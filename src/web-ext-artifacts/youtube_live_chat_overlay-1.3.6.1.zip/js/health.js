/**
 * Health monitoring for chat overlay
 */

let lastMessageCount = 0;
let healthCheckInterval;
let noNewMessagesCount = 0;

/**
 * Start health monitoring to detect when chat updates stop
 */
function startHealthMonitoring() {
  // Clear any existing health check
  if (healthCheckInterval) {
    clearInterval(healthCheckInterval);
  }
  
  healthCheckInterval = setInterval(() => {
    if (!isOverlayVisible || !chatMessagesContainer) {
      return;
    }
    
    const currentMessageCount = chatMessagesContainer.children.length;
    
    // Check if we're still getting new messages
    if (currentMessageCount === lastMessageCount) {
      noNewMessagesCount++;
      
      // If no new messages for 30 seconds (6 checks * 5 seconds), try to refresh
      if (noNewMessagesCount >= 6) {
        log("No new messages detected for 30 seconds, attempting refresh");
        
        // Try to find a new chat frame
        const newFrame = findChatFrame();
        if (newFrame && newFrame !== liveChatFrame) {
          log("Found new chat frame during health check");
          liveChatFrame = newFrame;
          
          // Reset counters
          noNewMessagesCount = 0;
          lastMessageCount = currentMessageCount;
          
          // Restart intervals if needed
          if (updateInterval) {
            clearInterval(updateInterval);
            handleFullscreenChange(); // This will restart the update intervals
          }
        } else {
          // Reset counter to avoid endless logging
          noNewMessagesCount = 0;
        }
      }
    } else {
      // We got new messages, reset counter
      noNewMessagesCount = 0;
      lastMessageCount = currentMessageCount;
    }
    
  }, 5000); // Check every 5 seconds
}

/**
 * Stop health monitoring
 */
function stopHealthMonitoring() {
  if (healthCheckInterval) {
    clearInterval(healthCheckInterval);
    healthCheckInterval = null;
  }
  noNewMessagesCount = 0;
  lastMessageCount = 0;
}

/**
 * Reset health monitoring state
 */
function resetHealthMonitoring() {
  noNewMessagesCount = 0;
  lastMessageCount = chatMessagesContainer ? chatMessagesContainer.children.length : 0;
}
